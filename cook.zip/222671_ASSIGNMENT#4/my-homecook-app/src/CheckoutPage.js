import React, { useState, useEffect } from "react";
import "./CheckoutPage.css";
import axios from 'axios';

const dailyMenu = [
  { id: 1, name: "Chicken Biryani", price: 400, serves: 2 },
  { id: 2, name: "Paneer Butter Masala", price: 300, serves: 1 },
  { id: 3, name: "Butter Naan", price: 40, serves: 1 },
  { id: 4, name: "Gulab Jamun", price: 80, serves: 2 },
  { id: 5, name: "Masala Dosa", price: 150, serves: 1 },
  { id: 6, name: "Rajma Chawal", price: 200, serves: 1 },
  { id: 7, name: "Loaded Cheese Fries", price: 100, serves: 2 },
  { id: 8, name: "Mighty Zinger", price: 200, serves: 1 },
];

export default function CheckoutPage() {
  const [order, setOrder] = useState({});
  const [address, setAddress] = useState("");
  const [deliveryTime, setDeliveryTime] = useState("");

  useEffect(() => {
    const savedOrder = JSON.parse(localStorage.getItem("order")) || {};
    const savedDeliveryTime = localStorage.getItem("deliveryTime") || "";
    setOrder(savedOrder);
    setDeliveryTime(savedDeliveryTime);
  }, []);

  const total = Object.entries(order).reduce((acc, [id, persons]) => {
    const item = dailyMenu.find((i) => i.id === parseInt(id));
    const servingsNeeded = Math.ceil(persons / item.serves);
    return acc + servingsNeeded * item.price;
  }, 0);

  const handleConfirm = async () => {
    if (!address.trim()) {
      alert("Please enter a delivery address.");
      return;
    }

    // Create order items
    const items = Object.entries(order).map(([id, persons]) => {
      const item = dailyMenu.find((i) => i.id === parseInt(id));
      const quantity = Math.ceil(persons / item.serves);
      return { name: item.name, quantity };
    });

    try {
      const response = await axios.post("http://localhost:5000/api/orders", {
        items,
        deliveryTime,
      });

      alert("Order placed successfully!");
      localStorage.removeItem("order");
      localStorage.removeItem("deliveryTime");
    } catch (error) {
      console.error("Order submission failed:", error);
      alert("Failed to submit order. Please try again.");
    }
  };

  return (
    <div className="checkout-page">
      <h1>Checkout</h1>

      <div className="bill-container">
        <h2>Order Summary</h2>
        <table className="bill-table">
          <thead>
            <tr>
              <th>Item</th>
              <th>Qty</th>
              <th>Price</th>
              <th>Subtotal</th>
            </tr>
          </thead>
          <tbody>
            {Object.entries(order).map(([id, persons]) => {
              const item = dailyMenu.find((i) => i.id === parseInt(id));
              const qty = Math.ceil(persons / item.serves);
              const subtotal = qty * item.price;
              return (
                <tr key={id}>
                  <td>{item.name}</td>
                  <td>{qty}</td>
                  <td>₹{item.price}</td>
                  <td>₹{subtotal}</td>
                </tr>
              );
            })}
          </tbody>
        </table>

        <div className="bill-total">
          <strong>Total:</strong> ₹{total}
        </div>
        <div className="bill-delivery">
          <strong>Delivery Time:</strong> {new Date(deliveryTime).toLocaleString()}
        </div>
        <textarea
          placeholder="Enter delivery address"
          value={address}
          onChange={(e) => setAddress(e.target.value)}
          className="address-input"
        />
        <button className="proceed-button" onClick={handleConfirm}>
          Confirm Order
        </button>
      </div>
    </div>
  );
}
