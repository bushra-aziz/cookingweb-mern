import React from 'react';
import { Link } from 'react-router-dom';
import './AdminPanel.css';

export default function AdminPanel() {
  return (
    <div className="admin-panel">
      <h2>Admin Dashboard</h2>
      <div className="admin-links">
        <Link to="/admin/manage-food">🍔 Manage Food</Link>
        <Link to="/admin/view-orders">📦 View Orders</Link>
      </div>
    </div>
  );
}
