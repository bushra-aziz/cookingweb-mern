import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import axios from 'axios';
import './AdminPanel.css';

export default function ViewOrders() {
  const orders = useSelector(state => state.orders);
  const dispatch = useDispatch();

  useEffect(() => {
    axios.get('/api/orders').then((res) => {
      dispatch({ type: 'SET_ORDERS', payload: res.data });
    });
  }, [dispatch]);

  return (
    <div className="admin-panel">
      <h2>View Orders</h2>
      {orders.length === 0 ? <p>No orders found.</p> :
        <ul className="order-list">
          {orders.map(order => (
            <li key={order._id}>
              <p><strong>User:</strong> {order.user?.name || "Unknown"}</p>
              <p><strong>Items:</strong> {order.items.map(i => `${i.name} (x${i.quantity})`).join(', ')}</p>
              <p><strong>Total:</strong> ${order.total}</p>
              <hr />
            </li>
          ))}
        </ul>
      }
    </div>
  );
}
