const express = require('express');
const router = express.Router();
const Order = require('../models/order');
const { protect, isAdmin } = require('../middleware/authMiddleware');

// Get all orders (admin only)
router.get('/', protect, isAdmin, async (req, res) => {
  const orders = await Order.find().populate('user', 'name email');
  res.json(orders);
});

module.exports = router;
