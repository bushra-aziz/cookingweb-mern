const express = require('express');
const router = express.Router();
const Food = require('../models/Food');
const { protect, isAdmin } = require('../middleware/authMiddleware');

// GET all food
router.get('/', async (req, res) => {
  const foods = await Food.find();
  res.json(foods);
});

// POST add food
router.post('/', protect, isAdmin, async (req, res) => {
  const { name, price } = req.body;
  const newFood = new Food({ name, price });
  await newFood.save();
  res.status(201).json(newFood);
});

// DELETE food
router.delete('/:id', protect, isAdmin, async (req, res) => {
  await Food.findByIdAndDelete(req.params.id);
  res.json({ msg: "Food item deleted" });
});

module.exports = router;
