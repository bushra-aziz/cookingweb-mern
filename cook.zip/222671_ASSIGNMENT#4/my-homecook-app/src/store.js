import { createStore } from 'redux';

// Define initial state
const initialState = {
  foods: [],
  orders: [],
};

// Reducer function
function appReducer(state = initialState, action) {
  switch (action.type) {
    case 'SET_FOODS':
      return { ...state, foods: action.payload };
    case 'SET_ORDERS':
      return { ...state, orders: action.payload };
    default:
      return state;
  }
}

// Create Redux store
const store = createStore(appReducer);

export default store;
