require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const ordersRoute = require('./routes/orderRoutes');
const foodRoute = require('./routes/foodRoutes');
const authRoute = require('./routes/auth'); // Include your auth route if using

const app = express();

// ====== Middleware ======
app.use(cors());
app.use(express.json());

// ====== Check for MongoDB URI ======
if (!process.env.MONGO_URI) {
  console.error('❌ MONGO_URI not found in .env');
  process.exit(1);
}

// ====== MongoDB Connection ======
mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
  .then(() => console.log('✅ MongoDB connected'))
  .catch(err => {
    console.error('❌ MongoDB connection error:', err);
    process.exit(1); // Exit on failure
  });

// ====== API Routes ======
app.use('/api/orders', ordersRoute);
app.use('/api/foods', foodRoute);
app.use('/api/auth', authRoute); // Add this line if using login/register/etc.

// ====== Test Route ======
app.get('/api/test', (req, res) => {
  res.json({ message: 'Server working! ✅' });
});

// ====== Start Server ======
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});
