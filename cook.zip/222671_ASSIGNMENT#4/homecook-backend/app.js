const express = require("express");
const connectDB = require("./config/db");
const orderRoutes = require("./routes/Orders");

const app = express();
const PORT = process.env.PORT || 5000;

connectDB();
app.use(express.json());

app.use("/api/orders", orderRoutes);

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
