const express = require("express");
const router = express.Router();
const Order = require("../models/order");

router.post("/", async (req, res) => {
  try {
    const { items, deliveryTime } = req.body;
    const now = new Date();
    const delivery = new Date(deliveryTime);
    const diffHours = (delivery - now) / (1000 * 60 * 60);

    if (diffHours < 5) {
      return res.status(400).json({ error: "Delivery time must be at least 5 hours from now." });
    }

    const order = new Order({ items, deliveryTime });
    await order.save();

    res.status(201).json({ message: "Order created", order });
  } catch (err) {
    res.status(500).json({ error: "Server error" });
  }
});

router.get("/", async (req, res) => {
  try {
    const orders = await Order.find().sort({ createdAt: -1 });
    res.json(orders);
  } catch (err) {
    res.status(500).json({ error: "Server error" });
  }
});

module.exports = router;
