import React, { useContext } from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import HomePage from "./HomePage";
import CheckoutPage from "./CheckoutPage";
import Login from "./Login";
import Register from "./RegisterPage";
import ResetPassword from "./ResetPassword";
import AdminPanel from "./Admin/AdminPanel";
import ManageFood from "./Admin/ManageFood";
import ViewOrders from "./Admin/ViewOrders";
import { AuthProvider, AuthContext } from "./AuthContext"; 
import ProtectedRoute from "./ProtectedRoute";

import "./App.css";

function AppRoutes() {
  const { user } = useContext(AuthContext);

  return (
    <Routes>
      {/* Default route shows login if user is not authenticated */}
      <Route path="/" element={user ? <Navigate to="/home" /> : <Navigate to="/login" />} />

      {/* Auth routes */}
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/reset-password/:token" element={<ResetPassword />} />

      {/* Protected Routes */}
      <Route
        path="/home"
        element={
          <ProtectedRoute>
            <HomePage />
          </ProtectedRoute>
        }
      />
      <Route
        path="/checkout"
        element={
          <ProtectedRoute>
            <CheckoutPage />
          </ProtectedRoute>
        }
      />

      {/* Admin Routes */}
      <Route
        path="/admin"
        element={
          <ProtectedRoute roles={["Admin"]}>
            <AdminPanel />
          </ProtectedRoute>
        }
      />
      <Route
        path="/admin/manage-food"
        element={
          <ProtectedRoute roles={["Admin"]}>
            <ManageFood />
          </ProtectedRoute>
        }
      />
      <Route
        path="/admin/view-orders"
        element={
          <ProtectedRoute roles={["Admin"]}>
            <ViewOrders />
          </ProtectedRoute>
        }
      />
    </Routes>
  );
}

function App() {
  return (
    <AuthProvider>
      <Router>
        <AppRoutes />
      </Router>
    </AuthProvider>
  );
}

export default App;
