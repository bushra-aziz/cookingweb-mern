// routes/auth.js

const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const router = express.Router();
const crypto = require('crypto');
const nodemailer = require('nodemailer');

// Mail sender setup (example using Gmail)
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: { user: '222671@students.au.edu.pk', pass: 'bushra456' },
});

// Registration
router.post('/register', async (req, res) => {
  const { name, email, password } = req.body;
  try {
    const existingUser = await User.findOne({ email });
    if (existingUser) return res.status(400).json({ msg: 'Email already exists' });

    const hash = await bcrypt.hash(password, 10);
    const verificationToken = crypto.randomBytes(20).toString('hex');

    const user = new User({
      name,
      email,
      password: hash,
      verificationToken,
    });
    await user.save();

    const url = `http://localhost:3000/verify/${verificationToken}`;
    await transporter.sendMail({
      to: email,
      subject: 'Verify Your Email',
      html: `<p>Click <a href="${url}">here</a> to verify.</p>`
    });

    res.status(201).json({ msg: 'Registration successful, verify email' });
  } catch (err) {
    res.status(500).json({ msg: err.message });
  }
});

// Verify Email
router.get('/verify/:token', async (req, res) => {
  const user = await User.findOne({ verificationToken: req.params.token });
  if (!user) return res.status(400).json({ msg: 'Invalid token' });

  user.isVerified = true;
  user.verificationToken = undefined;
  await user.save();

  res.json({ msg: 'Email verified successfully' });
});

// Login
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email });
  if (!user || !user.isVerified) return res.status(400).json({ msg: 'Invalid or unverified user' });

  const isMatch = await bcrypt.compare(password, user.password);
  if (!isMatch) return res.status(400).json({ msg: 'Incorrect password' });

  const token = jwt.sign({ id: user._id, role: user.role }, 'jwt_secret', { expiresIn: '1h' });
  res.json({ token });
});

// Middleware for role-based access
const authMiddleware = (roles = []) => {
  return (req, res, next) => {
    const token = req.headers['authorization'];
    if (!token) return res.status(401).json({ msg: 'Unauthorized' });

    try {
      const decoded = jwt.verify(token, 'jwt_secret');
      if (roles.length && !roles.includes(decoded.role)) {
        return res.status(403).json({ msg: 'Forbidden' });
      }
      req.user = decoded;
      next();
    } catch {
      res.status(401).json({ msg: 'Invalid token' });
    }
  };
};

// Forgot Password
router.post('/forgot-password', async (req, res) => {
  const { email } = req.body;
  const user = await User.findOne({ email });
  if (!user) return res.status(400).json({ msg: 'No account found' });

  const resetToken = crypto.randomBytes(32).toString('hex');
  user.resetToken = resetToken;
  user.resetTokenExpire = Date.now() + 3600000; // 1 hour
  await user.save();

  const resetURL = `http://localhost:3000/reset-password/${resetToken}`;
  await transporter.sendMail({
    to: email,
    subject: 'Password Reset',
    html: `<p>Click <a href="${resetURL}">here</a> to reset password.</p>`
  });

  res.json({ msg: 'Password reset email sent' });
});
const { protect } = require('../middleware/authMiddleware'); // or adjust the path if different

// ✅ Get current authenticated user
router.get('/user', protect, async (req, res) => {
  try {
    res.json({ user: req.user }); // `req.user` is already set by protect middleware
  } catch (error) {
    res.status(500).json({ msg: "Server error" });
  }
});

// Reset Password
router.post('/reset-password/:token', async (req, res) => {
  const user = await User.findOne({
    resetToken: req.params.token,
    resetTokenExpire: { $gt: Date.now() }
  });

  if (!user) return res.status(400).json({ msg: 'Invalid or expired token' });

  const hashed = await bcrypt.hash(req.body.password, 10);
  user.password = hashed;
  user.resetToken = undefined;
  user.resetTokenExpire = undefined;
  await user.save();

  res.json({ msg: 'Password reset successful' });
});

module.exports = router; // ✅ only export the router

// Optionally also export middleware if needed elsewhere
module.exports.authMiddleware = authMiddleware;
