import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import axios from 'axios';
import './AdminPanel.css';

export default function ManageFood() {
  const foods = useSelector(state => state.foods);
  const dispatch = useDispatch();
  const [newFood, setNewFood] = useState({ name: '', price: '' });

  useEffect(() => {
    axios.get('/api/foods').then((res) => {
      dispatch({ type: 'SET_FOODS', payload: res.data });
    });
  }, [dispatch]);

  const addFood = async (e) => {
    e.preventDefault();
    const res = await axios.post('/api/foods', newFood);
    dispatch({ type: 'SET_FOODS', payload: [...foods, res.data] });
    setNewFood({ name: '', price: '' });
  };

  const deleteFood = async (id) => {
    await axios.delete(`/api/foods/${id}`);
    dispatch({ type: 'SET_FOODS', payload: foods.filter(f => f._id !== id) });
  };

  return (
    <div className="admin-panel">
      <h2>Manage Food Items</h2>
      <form onSubmit={addFood} className="admin-form">
        <input type="text" placeholder="Name" value={newFood.name} onChange={(e) => setNewFood({ ...newFood, name: e.target.value })} required />
        <input type="number" placeholder="Price" value={newFood.price} onChange={(e) => setNewFood({ ...newFood, price: e.target.value })} required />
        <button type="submit">Add Food</button>
      </form>
      <ul className="food-list">
        {foods.map(f => (
          <li key={f._id}>
            {f.name} - ${f.price}
            <button onClick={() => deleteFood(f._id)}>❌</button>
          </li>
        ))}
      </ul>
    </div>
  );
}
