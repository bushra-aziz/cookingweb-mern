import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./HomePage.css";
import axios from 'axios';

const dailyMenu = [
  { id: 1, name: "Chicken Biryani", image: "/images/chicken-biryani.webp", price: 400, serves: 2 },
  { id: 2, name: "Paneer Butter Masala", image: "/images/paneer.jpeg", price: 300, serves: 1 },
  { id: 3, name: "Butter Naan", image: "/images/butter-naan.jpg", price: 40, serves: 1 },
  { id: 4, name: "Gulab Jamun", image: "/images/gulab-jamun.jpg", price: 80, serves: 2 },
  { id: 5, name: "Masala Dosa", image: "/images/masala-dosa.jpg", price: 150, serves: 1 },
  { id: 6, name: "Rajma Chawal", image: "/images/chawal.jpeg", price: 200, serves: 1 },
  { id: 7, name: "Loaded Cheese Fries", image: "/images/cheese-fries.jpg", price: 100, serves: 2 },
  { id: 8, name: "Mighty Zinger", image: "/images/zinger.png", price: 200, serves: 1 },
];

export default function HomePage() {
  const [order, setOrder] = useState({});
  const [deliveryTime, setDeliveryTime] = useState("");
  const navigate = useNavigate();

  const handleOrderChange = (id, persons) => {
    // Ensure the number of persons is a valid number (greater than 0)
    if (persons > 0) {
      setOrder({ ...order, [id]: persons });
    }
  };

  const handleSubmit = () => {
    if (!deliveryTime) {
      alert("Please select a delivery date and time.");
      return;
    }
  
    if (Object.keys(order).length === 0) {
      alert("Please select at least one item to order.");
      return;
    }
  
    const now = new Date();
    const selected = new Date(deliveryTime);
  
    const diffInMs = selected.getTime() - now.getTime();
    const diffInHours = diffInMs / (1000 * 60 * 60);
  
    if (diffInHours < 5) {
      alert("Delivery time must be at least 5 hours from now.");
      return;
    }
  
    localStorage.setItem("order", JSON.stringify(order));
    localStorage.setItem("deliveryTime", deliveryTime);
    navigate("/checkout");
  };
  
  return (
    <div className="home-page">
      <header className="home-header" style={{ flexDirection: "column", alignItems: "center" }}>
        <div className="brand">
          <img src="/images/cook.png" alt="HomeCook Logo" className="logo" />
          <h1 className="brand-name">HomeCook</h1>
        </div>
        <h2 className="menu-heading">Today's Menu</h2>
      </header>

      <div className="food-list">
        {dailyMenu.map((item) => (
          <div className="food-card" key={item.id}>
            <img src={item.image} alt={item.name} />
            <h3>{item.name}</h3>
            <p>Price: ₹{item.price}</p>
            <p>Serves: {item.serves} person(s)</p>
            <input
              type="number"
              min="1"
              placeholder="Number of persons"
              onChange={(e) => handleOrderChange(item.id, parseInt(e.target.value))}
            />
          </div>
        ))}
      </div>

      <div className="datetime-section">
        <h3 className="delivery-heading">Select Delivery Date & Time</h3>
        <input
          type="datetime-local"
          value={deliveryTime}
          onChange={(e) => setDeliveryTime(e.target.value)}
          className="datetime-input"
        />
        <button className="proceed-button" onClick={handleSubmit}>
          Proceed to Checkout
        </button>
      </div>
    </div>
  );
}
